// const mongoose = require('mongoose');
// const bcrypt = require('bcrypt');

// const userSchema = new mongoose.Schema(
//     {
//         name: {
//             type: String,
//             required: true,
//         },
//         email: {
//             type: String,
//             unique: true,
//             required: true,
//         },
//         password: {
//             type: String,
//             required: true,
//         },
//     },

//     {timestamps: true}
// );
// // create a virtual property to set hashed password
// userSchema.virtual('password').set(async function(value){
//     this.password =await bcrypt.hash(value, 12);
// });

// //function to compare hashed password
// userSchema.methods.isPasswordCorrect =async function(password){
//     return await bcrypt.compare(password, this.password);
//     // console.log(this.password, password);
// };

// const User = mongoose.model('User', userSchema);

// module.exports = User;

const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        unique: true,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    confirmpassword: {
        type: String,
        required: true,
        validate: {
            validator: function (value) {
                return this.password === value;
            },
            message: 'Password Do not match'
        }
    }
});

const User = mongoose.model('User', UserSchema);
module.exports= User;